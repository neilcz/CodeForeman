def fib(n):
    """返回第 n 个斐波那契数（从 0 开始：fib(0)=0, fib(1)=1）。"""
    if n < 0:
        raise ValueError("n 必须是非负整数")
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def main():
    import argparse

    parser = argparse.ArgumentParser(description="打印第 n 个斐波那契数")
    parser.add_argument("n", type=int, help="非负整数下标（从 0 开始）")
    args = parser.parse_args()
    print(fib(args.n))


if __name__ == "__main__":
    main()
